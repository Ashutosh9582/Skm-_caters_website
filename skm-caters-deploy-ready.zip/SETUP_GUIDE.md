# SKM Caters: database + email setup (ek baar, ~15 minute, free)

## 1. Firebase (reviews, photos, enquiries ka database)
1. console.firebase.google.com > Add project (Analytics off).
2. Build > **Firestore Database** > Create database > production mode.
3. Project settings > Your apps > Web (`</>`) > app register > `firebaseConfig` ki 4 values `js/config.js` me `FIREBASE_CONFIG` me paste karo.
4. Build > **Authentication** > Get started > Email/Password enable > Users > **Add user** (apna email + password). Ye owner.html ka login hai.
5. Firestore > **Rules** me ye paste karke Publish karo (yahan OWNER_EMAIL ki jagah wahi email daalo):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    function owner() { return request.auth != null && request.auth.token.email == 'OWNER_EMAIL'; }
    match /reviews/{id} {
      allow read: if resource.data.approved == true || owner();
      allow create: if request.resource.data.approved == false
        && request.resource.data.name is string && request.resource.data.name.size() < 80
        && request.resource.data.text is string && request.resource.data.text.size() < 1000
        && request.resource.data.rating >= 1 && request.resource.data.rating <= 5;
      allow update, delete: if owner();
    }
    match /photos/{id}    { allow read: if true; allow write: if owner(); }
    match /enquiries/{id} { allow create: if true; allow read, update, delete: if owner(); }
  }
}
```
Isse customer sirf review/enquiry likh sakta hai; approve, delete, photo upload sirf owner kar sakta hai.

## 2. Email (har enquiry/review aapke mail par)
web3forms.com > apna email daalo > Access Key mail me aayegi > `js/config.js` me `WEB3FORMS_KEY`.

## 3. Roz ka use
- `owner.html` kholo > login > naye reviews **Approve**, photos upload, enquiries dekho.
- Customer WhatsApp button dabaye to message customer ke phone se aapke number par jaata hai (WhatsApp automatic bhejne ki permission nahi deta).

## Dhyan
- Photos Firestore me compress hoke save hoti hain (free plan par chalta hai). Zyada (100+) photos ho to Firebase Storage (paid plan) behtar hai.
- `owner.html` ka link public menu me nahi hai; password strong rakho.
