# SKM Caters: deploy guide (website folder upload karne se pehle)

Upload karna hai sirf `website/` folder. Ye dono guide files (DEPLOY_GUIDE.md, SETUP_GUIDE.md) site ke saath upload mat karna.

## Jo maine kar diya hai
- Phone **+91 95099 07261** aur email **ashutoshbeel@gmail.com**: footer, call link, WhatsApp button, email link aur Google ke business data (schema) me.
- SEO: title, description, keywords, Google share preview (WhatsApp/Facebook), local business schema (Green Park, Delhi 110016), robots.txt, sitemap.xml, har photo ka alt text, ek hi H1.
- owner.html Google se chhupa hua hai (noindex).
- Photos compress ki (images 14 MB se kam ho gayi), site tez khulegi.
- Header ka bada logo theek kiya (pehle poori size me banner par chhaya hua tha).
- 404.html aur `_headers` (Netlify security headers) jode.

## Deploy se pehle 3 kaam (zaroori)

### 1. Apna domain/link daalo (3 files me)
Site live hone par jo link mile (jaise `https://skmcaters.netlify.app` ya apna domain), VS Code me **Ctrl+Shift+H** (Replace in Files) kholo:
- Find: `https://YOUR-DOMAIN.com`
- Replace: aapka asli link (end me `/` mat lagana)

Ye `index.html`, `robots.txt` aur `sitemap.xml` me badlega.

### 2. Firebase keys (`website/js/config.js`)
`FIREBASE_CONFIG` me abhi `PASTE_HERE` hai. Jab tak asli keys nahi daaloge, reviews, gallery photos aur enquiry database kaam nahi karenge. Steps `SETUP_GUIDE.md` me hain. Owner login ke liye wahi email use karo jo rules me `OWNER_EMAIL` me daaloge.

### 3. Web3Forms key
web3forms.com par **ashutoshbeel@gmail.com** se Access Key banao aur `WEB3FORMS_KEY` me paste karo. Tabhi enquiry/review is email par aayegi.

## Deploy kaise karein (free)
**Netlify (sabse aasan):** app.netlify.com/drop kholo, `website` folder drag & drop karo. Link turant mil jaata hai. Link badalne par step 1 dobara karke folder phir se drop karo.
Dusre options: GitHub Pages, Cloudflare Pages.

## Live hone ke baad
1. Google Search Console me site add karo aur `sitemap.xml` submit karo.
2. Google Business Profile banao (Green Park, Delhi). "caterers near me" searches ke liye ye sabse zaroori hai.
3. Link ko WhatsApp par bhej ke share preview check karo.
4. Pehle 5-10 asli reviews approve karo.

## Dhyan dene wali baatein
- Gallery/Specials ki photos abhi template ki stock photos hain (burger, pizza, chicken, meatballs). Menu vegetarian hai, to "Shahi Paneer" ke saath chicken ki photo dikhti hai. `images/` me **wahi file naam** rakh ke apni asli photos daalo. Specials ka alt text dish ke naam par pehle se set hai.
- `index.html` me keywords me "vegetarian catering" likha hai. Agar aap non-veg bhi dete ho to use hata do.
- Address me "Yusuf Sari" likha hai. Agar sahi spelling "Yusuf Sarai" hai to footer aur schema dono me badlo.
- Facebook/Instagram icons abhi `#` par hain. Pages ban jaayein to unke link daalo.
